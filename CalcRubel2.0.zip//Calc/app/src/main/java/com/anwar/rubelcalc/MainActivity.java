package com.anwar.rubelcalc;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

//3rd party library to eval exprassion
import net.objecthunter.exp4j.*;


public class MainActivity extends Activity
{
    TextView textView;
	TextView answerView;
    
    String expr = "";
	double result;
	
    boolean is_complete = false;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
       super.onCreate(savedInstanceState);

       // Set main.xml as user interface layout
       setContentView(R.layout.main);
       
	   textView = (TextView) findViewById(R.id.displayExpr);
       answerView = (TextView) findViewById(R.id.displayAnswer);
	   expr = expr + textView.getText();
    }
	
	private void evalTheExpr() {
		expr = textView.getText() + "";
		
		if (!expr.equals("")) {
			Expression e = new ExpressionBuilder(expr).build();
			ValidationResult res = e.validate();
			if (res.isValid()) {
				result = e.evaluate();
			} else {
				answerView.setText("");
				return;
			}
			//result = e.evaluate();
			answerView.setText(result + "");
		} else {
			answerView.setText("");
		}
	}
     
	 private void setNumber(String num) {
		 textView.setText(textView.getText() + num);
		 is_complete = false;
		 //TODO
		 //evalTheExpr();
	 }
	 
     public void clickButton0(View v){
		 setNumber("0");
     }
     public void clickButton1(View v){
         setNumber("1");
     }
     
     public void clickButton2(View v){
         setNumber("2");
     }
     
     public void clickButton3(View v){
         setNumber("3");
     }
     
     public void clickButton4(View v){
         setNumber("4");
     }
     
     public void clickButton5(View v){
         setNumber("5");
     }
     
     public void clickButton6(View v){
         setNumber("6");
     }
     
     public void clickButton7(View v){
         setNumber("7");
     }
     
     public void clickButton8(View v){
         setNumber("8");
     }
     
     public void clickButton9(View v){
         setNumber("9");
     }
     
    public void clickButtonAdd(View v){
        textView.setText(textView.getText()+"+");
    }
     
	public void clickButtonSub(View v){
		textView.setText(textView.getText()+"-");
	}
     
	public void clickButtonMul(View v){
		textView.setText(textView.getText()+"*");
	}
     
	public void clickButtonDiv(View v){
		textView.setText(textView.getText()+"/");
	}
	
     public void clickButtonSin(View v) {
		 textView.setText(textView.getText()+"sin(");
     }
     
     public void clickButtonCos(View v) {
		 textView.setText(textView.getText()+"cos(");
	 }
     
     public void clickButtonTan(View v) {
		 textView.setText(textView.getText()+"tan(");
	 }
     
     public void clickButtonSqrt(View v) {
         textView.setText(textView.getText()+"sqrt(");
     }
	 
	public void clickButtonBr1(View v) {
		textView.setText(textView.getText()+"(");
	}
	
	public void clickButtonBr2(View v) {
		textView.setText(textView.getText()+")");
	}
	
	public void clickButtonDot(View v) {
		textView.setText(textView.getText()+".");
	}
	
	public void clickButtonIndex(View v) {
		textView.setText(textView.getText()+"^");
	}
	
	public void clickButtonLn(View v) {
		textView.setText(textView.getText()+"log(");
	}
     
	 public void clickButtonClear(View v){
		 expr = textView.getText() + "";
		 
		 if (is_complete) {
			 expr = "";
			 textView.setText(expr);
			 answerView.setText(expr);
			 is_complete = false;
			 return;
		 }
		 
		 if(!expr.equals("")){
			expr = expr.substring(0, expr.length()-1);
		 	textView.setText(expr);
			//TODO
			//evalTheExpr();
		 }
	 }
     
     public void clickButtonEqual(View v){   
     	evalTheExpr();
		is_complete = true;
     }
}
